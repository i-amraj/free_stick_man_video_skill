# GrowKaz Stickman Studio — All-In-One Master Agent Bundle

Welcome to the **GrowKaz Stickman Studio** complete AI agent bundle.
This archive contains **EVERY SINGLE SKILL** (59 skills), full FK character rig with custom face shapes, ~35 pure SVG props, procedural backgrounds engine, continuous camera motion doctrines, and tested end-to-end video pipelines.

---

## 🌟 What Is Included in This Archive

### 1. Skills (Total: 59 Complete Skills)
All skills are packaged in both `.agents/skills/` AND top-level `skills/` for universal compatibility with Antigravity, Claude Code, Cursor, Windsurf, Roo Code, and Gemini CLI.

#### A. Core 2D Stickman & Video Production Skills
1. **character-animation** — FK by rotation rig (`rig.js`), 5 face styles (square, pointed, oval, chubby, round), ~35 SVG props (`props.js`), viseme lip-sync (`hero.talk()`), walk/run/dance cycles, ground contact.
2. **procedural-backgrounds** — 100% SVG code-only sets (medieval rooms, boutique shops, cobblestone alleys, winter streetlamps).
3. **gsap-motion** — "Camera Kabhi Rukta Nahi" continuous camera motion law, velocity-matched seams, punch zooms, handheld micro-drift.
4. **make-2d-video** — Multi-scene 2D production orchestrator, character staging, and timeline composition.
5. **new-video** — Scaffolding, 3-second beat breakdown, script-to-storyboard generation.
6. **video-styles** — Aesthetic lock-in ("look lock"), 7px stroke rule, 4 color palettes (`growkaz_mystery`).
7. **video-sound** — Voiceover synthesis, whoosh/pop SFX taxonomy, auto-ducking BGM (-14 LUFS broadcast standard).
8. **render-video** — Headless frame-accurate capture via deterministic virtual clock (`window.seekToTime(t)`), 5-gate automated QC.
9. **captions-overlay** — Kinetic karaoke typography, gold highlight `#FFD700`, 9:16 safe zones.

#### B. Seam & Cinematic Motion Skills
10. **motion-doctrine** — The vector law, carrier elements, causal motion, stillness before climax.
11. **cut-the-curve** — 5 velocity-matched transitions (zoom-through, waterfall, rack-focus blur).
12. **seam-craft** — Zero white-flash guard, stage-ground compositing, seamless scene handoffs.
13. **oversized-cursor** — Eye-carrier cursor, off-screen entry, click-ignition sequences.

#### C. Viral, Shorts & Editing Skills
14. **faceless-shorts** — Nafay3D 21-hook formula, neon split-screen layouts, 9:16 viral shorts.
15. **ai-video-editor** — Auto silence cutting, jumpcut punch-ins, B-roll overlays.
16. **changelog-video** — Branded markdown-to-video workflow.
17. **remotion-video** — Programmatic React motion graphics.
18. **remotion-to-hyperframes** — Code migration & frame verification.
19. **hyperframes** & **hyperframes-cli** — Deterministic HTML video renderer & CLI.
20. **threejs-scenes** — 3D stylized sets (Mystery Noir, Tech Vault, Minimalist Studio) composited with 2D.
21. **ui-ux-pro-max** — Full UI/UX intelligence, evidence cards, fonts, and charts.

#### D. Specialized Deep-Dive Animation & UI Skills
22. **gsap-core**, **gsap-timeline**, **gsap-scrolltrigger**, **gsap-plugins**, **gsap-react**, **gsap-frameworks**, **gsap-performance**, **gsap-utils** — The entire official GSAP mastery suite.
23. **banner-design**, **brand**, **design**, **design-system**, **slides**, **ui-styling** — Modular design intelligence.
24. **ai-video-generation**, **manim-animation**, **short-video-pipeline**, **b-roll-animator**, **visual-analyzer**, **youtube-agent**, **fact-storyboard-writer** — Facts & educational video animation skills.
25. **auto-job-applicator**, **permissioned-github**, **native_swarm**, **swarm_monitor**, **automation**, **generative_ui**, **plugin**, **antigravity_guide** — Workflow automation & agent orchestration.

---

## 2. Core Libraries (`core_libraries/`)
- `rig.js` — The official Forward Kinematics 2D Stickman rig with customizable head shapes, facial hair, clothing, visemes, and poses.
- `props.js` — ~35 pure SVG props (chest, coins, stinky shoe, crate, table, chair, sword, torch, magnifier, etc.).
- `gsap.min.js` — Bundled GreenSock Animation Platform library.

---

## 3. Working Pipelines & Templates (`templates_and_pipelines/`)
- `10s_character_demo/` — Working demo showcasing walking, running, crouching, jumping, and dancing.
- `20s_dialogue_video/` — Complete working 20-second project with Gary & Thief talking, lip-sync, shock reveals, custom faces, and continuous camera motion.
- `65s_full_procedural_film/` — The complete 8-scene procedural film pipeline.

---

## 4. Documentation & Intelligence (`docs/`)
- `ANALYSIS_REPORT.md` — Deep reverse-engineering of Comicron's viral style, motion curves, retention drivers, and audio architecture.
- `AGENT_PLAYBOOK.md` — Step-by-step instructions for an AI agent to build a new video from scratch.
- `CHARACTER_ANIMATION_GUIDE.md` — Rigging, angles, visemes, and animation guidelines.
- `STYLE_GUIDE.md` — Color palettes, font pairings, stroke weights, and safe zones.
- `AGENTS.md` & `GEMINI.md` — Complete workspace rules and instructions.

---

## 🚀 How to Use With Any AI Agent

1. Extract this zip archive into your project directory.
2. The rules in `AGENTS.md` (or `CLAUDE.md`, `.cursor/rules`) will automatically guide your AI agent.
3. Your agent will recognize all 59 skills in `.agents/skills/` and `skills/`.
4. Prompt your agent:
   > *"Read AGENTS.md and use make-2d-video and character-animation to create a video based on my script."*
