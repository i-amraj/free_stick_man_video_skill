---
name: ai-video-generation
description: >-
  Expert prompt engineering, scene composition, and workflow orchestration for
  text-to-video and image-to-video AI models (Google Veo, Sora, Kling, Runway Gen-3,
  LTX-Video, Minimax). Use when generating AI video clips, cinematic B-roll, or consistent characters.
---

# AI Video Generation & Prompt Engineering Skill

Use this skill to craft high-conversion prompts, ensure character/lighting consistency across scenes, and orchestrate generative video pipelines.

## The 6-Element Video Prompt Formula
Every top-tier AI video prompt should include:
1. **Subject**: Specific subject with attire, age, and appearance.
2. **Action / Motion**: Explicit verb and physics (e.g., *sprinting through puddles, water splashing in slow motion*).
3. **Camera Movement**: Drone shot, pan left-to-right, dolly zoom, orbit 360, low angle Dutch tilt, macro lens.
4. **Environment & Lighting**: Golden hour, neon cyberpunk, volumetric fog, dramatic chiaroscuro lighting.
5. **Aesthetics & Optics**: 35mm film grain, anamorphic lens flare, photorealistic, 8k resolution, cinematic shutter speed.
6. **Frame Rate / Temporal Pacing**: 60fps smooth motion, or 24fps cinematic film cadence.

### Example Cinematic Prompt:
> *Cinematic 35mm film shot of an ancient library at midnight. Floating dust particles illuminated by moonlight beams streaming through stained glass windows. Slow dolly forward toward a glowing leather-bound book on an oak pedestal. Soft volumetric fog, shallow depth of field, hyper-detailed textures, 4k 24fps.*

---

## Model-Specific Parameters & Strengths

| Model | Best For | Key Syntax / Directives |
| :--- | :--- | :--- |
| **Google Veo 3 / 3.1** | Complex physics, photorealism, high visual coherence | Describe natural motion and camera paths explicitly |
| **Runway Gen-3 Alpha** | Fast dynamic motion, camera control | Use tags: `[Camera: FPV drone]`, `[Motion: High]` |
| **Kling AI** | Human anatomy, expressive faces, physics simulation | Add descriptive facial micro-expressions |
| **OpenAI Sora** | Extended scene continuity, surrealist / stylized worlds | Include world rules and temporal continuity |
| **LTX-Video / Flux img2vid** | Open source local rendering, fast B-roll | Pair with detailed input image anchor |

---

## Maintaining Character Consistency (Multi-Shot Videos)
When creating sequential shots of the same person/character:
1. **Character Anchor Reference**: Always generate a high-detail front/profile image first (using Flux / Midjourney / Imagen).
2. **Fixed Anchor Tokens**: Keep hair color, eye color, clothing textures, and distinctive features strictly identical in each prompt:
   - Example: *"A 28-year-old female pilot, short raven hair, aviator brown leather jacket with white fur collar, silver scar on left cheek..."*
3. **Use Image-to-Video (I2V)**: Rather than text-to-video for characters, feed the still image into the I2V model and specify only the camera/character movement.
