# Production Storyboard: The Rogue Planet Fact

* **Target Length**: 32 Seconds
* **Pacing**: 140 WPM
* **Tone**: Mysterious, Sci-Fi, Dark Cinematic

---

### Scene Breakdown

#### Scene 1: The Hook (0.0s – 3.5s)
* **Voiceover**: *"Right now, there are billions of dark rogue planets wandering through our galaxy completely alone."*
* **Visual**: A dark, glowing frozen planet drifting through deep black space, illuminated only by distant starlight. Anamorphic lens flare, photorealistic 8k.
* **SFX**: `[Low deep space rumble + Whoosh]`

#### Scene 2: The Scale (3.5s – 11.0s)
* **Voiceover**: *"They have no sun, no sunrise, and no daylight. They were violently kicked out of their own solar systems by gravitational slingshots."*
* **Visual**: Dynamic simulation of a massive gas giant colliding gravitationally near a star and launching a rocky world into the pitch-black void.
* **SFX**: `[Subtle gravitational riser + Glass break ping]`

#### Scene 3: The Twist (11.0s – 22.0s)
* **Voiceover**: *"Yet scientists believe deep beneath their frozen surface, radioactive core decay could keep subterranean liquid oceans warm enough to harbor alien life."*
* **Visual**: Cross-section cutaway of a frozen ice planet showing geothermal hydrothermal vents glowing blue under an underground pitch-black ocean.
* **SFX**: `[Undersea sonar ping + Muffled bubbling]`

#### Scene 4: The Loop Ending (22.0s – 30.0s)
* **Voiceover**: *"Meaning thriving ecosystems could exist in total darkness, right now..."*
* **Visual**: Zoom out into the vast starry Milky Way galaxy as the frozen world vanishes into the void.
* **SFX**: `[Cinematic impact boom]`
* *(Loops seamlessly back into Scene 1: "...billions of dark rogue planets wandering...")*
