---
name: fact-storyboard-writer
description: >-
  Researches verified high-interest facts, eliminates debunked myths, crafts viral retention
  hooks, and generates complete multi-scene storyboards with image prompts, timing, and SFX cues.
---

# Fact Script & Storyboard Writer Skill

Use this skill when scripting educational shorts, debunking myths, crafting viral hooks, or converting raw factual trivia into engaging 30-60 second multi-scene video scripts.

## The Viral Hook Taxonomy
Never start a fact video with *"Did you know..."* or *"Today I will tell you..."*. Use one of these proven high-retention formulas:

1. **The Negative Hook**: *"Everything you've been told about [Topic] is a complete lie."*
2. **The Counter-Intuitive Truth**: *"This creature can survive outer space, boiling acid, and absolute zero temperatures."*
3. **The Hidden Warning**: *"If you ever see a square wave in the ocean, get out immediately. Here is why."*
4. **The Scale Shock**: *"You could fit every single planet in our solar system between the Earth and the Moon—with room to spare."*
5. **The Open Curiosity Gap**: *"In 1977, astronomers detected a signal from deep space that has never happened since."*

---

## Fact Verification Checklist (Never Spread Myths)
Before scripting any fact, verify against scientific consensus:
- **Reject Common Myths**: E.g., *"Humans only use 10% of their brain"*, *"Goldfish have a 3-second memory"*, *"Gum stays in your stomach for 7 years"*.
- **Quantify Explicitly**: Use concrete numbers rather than vague statements (e.g., *"1.3 million Earths fit inside the Sun"* instead of *"The sun is huge"*).
- **Cite the Mechanism**: Explain **why** it happens in 1 crisp sentence (e.g., *"Because honey contains almost zero moisture, bacteria literally dehydrate and die on contact"*).

---

## Multi-Scene Storyboard Format
Every produced fact script must follow this structured storyboard layout:

| Scene # | Time Window | Spoken Narration (Voiceover) | Visual B-Roll / Image Prompt | SFX / Audio Cue |
| :---: | :---: | :--- | :--- | :--- |
| **1 (Hook)** | 0.0s - 3.2s | *"Scientists discovered a place on Earth where rain has not fallen in 2 million years."* | Hyper-realistic drone shot over the dry McMurdo valleys in Antarctica, frozen brown soil, howling wind. | `[Heavy Sub-drop + Whoosh]` |
| **2 (Body)** | 3.2s - 8.5s | *"It's not the Sahara Desert—it's located right in Antarctica."* | Fast zoom in on satellite view of Earth spinning to Antarctica's ice-free valleys. | `[Fast Swoosh]` |
| **3 (Twist)** | 8.5s - 18.0s| *"Katabatic winds here reach 200 mph, evaporating all moisture before it ever touches the ground."* | Cinematic storm clouds forming high above, moisture evaporating into thin air, hyper-detailed. | `[Wind Gust + Low Riser]` |
| **4 (Loop)** | 18.0s - 25.0s| *"Which is why this remains the closest thing to Mars on our planet..."* | Comparison split-screen between Mars surface and Antarctic valley. | `[Impact Hit + Seamless loop]` |

---

## Sample Storyboards
See complete production-ready storyboards in:
[space_fact_storyboard.md](./examples/space_fact_storyboard.md)
