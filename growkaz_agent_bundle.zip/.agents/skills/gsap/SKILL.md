---
name: gsap
description: >
  Official GSAP (GreenSock Animation Platform) skill for Antigravity. Use this skill whenever the user
  asks to animate a webpage with GSAP, add scroll animations, use ScrollTrigger, build timelines,
  or when any JavaScript animation library is needed. This skill aggregates the full greensock/gsap-skills
  repository cloned locally at: C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\
  
  Sub-skills available (read the relevant SKILL.md before coding):
  - gsap-core        → tweens (to, from, fromTo, set), eases, stagger, matchMedia
  - gsap-scrolltrigger → scroll-driven animation, pinning, scrub, batch
  - gsap-timeline    → sequenced animations, labels, nested timelines
  - gsap-plugins     → Flip, Draggable, MorphSVG, TextPlugin, CustomEase
  - gsap-react       → useGSAP() hook, React cleanup
  - gsap-performance → GPU layers, will-change, avoiding layout thrash
  - gsap-frameworks  → Vue, Svelte, Astro usage
  - gsap-utils       → clamp, mapRange, pipe, unitize helpers
---

# GSAP Skill — Antigravity Master Entry

## How to Use This Skill

When GSAP is needed, **read the relevant sub-skill SKILL.md** from:
`C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\<sub-skill>\SKILL.md`

Always read at minimum:
- `gsap-core/SKILL.md` — for any tween usage
- `gsap-scrolltrigger/SKILL.md` — when scroll animation is involved
- `gsap-timeline/SKILL.md` — when sequencing multiple animations

## CDN Setup (Vanilla JS / HTML)

```html
<!-- Core GSAP -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<!-- ScrollTrigger plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<!-- TextPlugin (optional, for typewriter effects) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/TextPlugin.min.js"></script>

<script>
  gsap.registerPlugin(ScrollTrigger);
  // gsap.registerPlugin(TextPlugin); // if needed
</script>
```

## Lenis Smooth Scroll + ScrollTrigger Integration

When using Lenis for smooth scrolling alongside ScrollTrigger:

```html
<script src="https://unpkg.com/lenis@1.1.14/dist/lenis.min.js"></script>
<script>
  // 1. Init Lenis
  const lenis = new Lenis({ autoRaf: true });

  // 2. Connect to ScrollTrigger via scrollerProxy
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((time) => lenis.raf(time * 1000));
  gsap.ticker.lagSmoothing(0);
</script>
```

## Key Patterns for Portfolio Sites

### Scroll-reveal cards (stagger on enter)
```javascript
gsap.registerPlugin(ScrollTrigger);

ScrollTrigger.batch(".card", {
  onEnter: (elements) => {
    gsap.from(elements, {
      y: 60,
      autoAlpha: 0,
      duration: 0.8,
      stagger: 0.12,
      ease: "power3.out"
    });
  },
  start: "top 85%",
  once: true
});
```

### Hero heading character-split reveal
```javascript
// Split text into spans manually (no SplitText plugin needed)
function splitChars(el) {
  const text = el.textContent;
  el.innerHTML = text.split('').map(ch =>
    ch === ' ' ? ' ' : `<span class="char" style="display:inline-block">${ch}</span>`
  ).join('');
  return el.querySelectorAll('.char');
}

const chars = splitChars(document.querySelector('.hero-title'));
gsap.from(chars, {
  y: 80,
  autoAlpha: 0,
  duration: 0.6,
  stagger: 0.03,
  ease: "power3.out"
});
```

### Section header fade-up on scroll
```javascript
gsap.utils.toArray('.section-header').forEach(el => {
  gsap.from(el, {
    y: 40,
    autoAlpha: 0,
    duration: 0.8,
    ease: "power2.out",
    scrollTrigger: {
      trigger: el,
      start: "top 80%",
      once: true
    }
  });
});
```

### Timeline draw-on line (SVG or pseudo-element height)
```javascript
gsap.from(".timeline-line", {
  scaleY: 0,
  transformOrigin: "top center",
  duration: 1.5,
  ease: "power2.out",
  scrollTrigger: {
    trigger: ".journey-section",
    start: "top 60%",
    once: true
  }
});
```

### Counter count-up animation
```javascript
const counters = document.querySelectorAll('[data-count]');
counters.forEach(counter => {
  const target = +counter.dataset.count;
  gsap.from({ val: 0 }, {
    val: target,
    duration: 2,
    ease: "power2.out",
    onUpdate() { counter.textContent = Math.round(this.targets()[0].val) + '+'; },
    scrollTrigger: {
      trigger: counter,
      start: "top 80%",
      once: true
    }
  });
});
```

### Parallax background orbs
```javascript
gsap.to(".orb-1", {
  y: -120,
  ease: "none",
  scrollTrigger: {
    trigger: "body",
    start: "top top",
    end: "bottom bottom",
    scrub: 1.5
  }
});
```

### 3D tilt effect on mousemove (no GSAP plugin needed)
```javascript
document.querySelectorAll('[data-tilt]').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const rect = card.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    gsap.to(card, {
      rotationY: x * 16,
      rotationX: -y * 16,
      transformPerspective: 900,
      duration: 0.4,
      ease: "power1.out"
    });
  });
  card.addEventListener('mouseleave', () => {
    gsap.to(card, { rotationY: 0, rotationX: 0, duration: 0.5, ease: "power2.out" });
  });
});
```

## Critical Rules (from official GSAP skills)

- ✅ Always `gsap.registerPlugin(ScrollTrigger)` BEFORE any ScrollTrigger usage
- ✅ Use `autoAlpha` instead of `opacity` for enter/exit animations
- ✅ Use transform aliases (`x`, `y`, `scale`) NOT CSS `transform` strings
- ✅ For Lenis + ScrollTrigger: connect via `lenis.on('scroll', ScrollTrigger.update)` and `gsap.ticker.add`
- ✅ Use `once: true` on ScrollTrigger for one-time entrance animations
- ✅ Use `stagger` for animating groups of cards
- ❌ Do NOT put ScrollTrigger on child tweens inside a timeline
- ❌ Do NOT use `markers: true` in production
- ❌ Do NOT animate `width`/`height`/`top`/`left` — use transforms

## Sub-skill File Locations

| Sub-skill | Path |
|---|---|
| gsap-core | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-core\SKILL.md` |
| gsap-scrolltrigger | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-scrolltrigger\SKILL.md` |
| gsap-timeline | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-timeline\SKILL.md` |
| gsap-plugins | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-plugins\SKILL.md` |
| gsap-performance | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-performance\SKILL.md` |
| gsap-utils | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-utils\SKILL.md` |
| gsap-react | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-react\SKILL.md` |
| gsap-frameworks | `C:\Users\iamra\.gemini\antigravity\skills\gsap-skills-repo\skills\gsap-frameworks\SKILL.md` |
