---
name: manim-animation
description: >-
  Creates mathematical, algorithmic, and educational explainer animations using Manim
  Community Edition (3Blue1Brown style). Use when animating equations, geometric figures,
  data structures, physics concepts, or syncing STEM visual narratives.
---

# Manim Explainer Animation Skill

Manim Community (`manim`) is a Python engine for precise mathematical and programmatic animations.

## Environment Setup
```bash
pip install manim
# Ensure FFmpeg is installed and accessible on PATH
```

## Quick Rendering Commands
```bash
# Preview low-quality (fast iteration):
manim -pql scene.py ExplainerScene

# High-definition (1080p60) export:
manim -pqh scene.py ExplainerScene

# 4K production render:
manim -pqk scene.py ExplainerScene

# Output transparent background (for overlays):
manim -pqh -t scene.py ExplainerScene
```

---

## Animation Principles & Best Practices

1. **Scene Lifecycle**:
   Every animation inherits from `Scene` and defines `construct(self)`:
   ```python
   from manim import *

   class ExplainerScene(Scene):
       def construct(self):
           title = Text("Neural Network Weights", font_size=40).to_edge(UP)
           self.play(Write(title), run_time=1.5)
           self.wait(1)
   ```

2. **Equations with MathTex**:
   ```python
   formula = MathTex(r"E = m c^2", font_size=72, color=YELLOW)
   self.play(FadeIn(formula, shift=UP))
   self.play(formula.animate.scale(1.2).set_color(BLUE))
   self.wait(2)
   ```

3. **Smooth Transformations**:
   Use `Transform` or `ReplacementTransform` to morph one shape or formula into another:
   ```python
   circle = Circle(radius=2, color=RED)
   square = Square(side_length=3, color=GREEN)

   self.play(Create(circle))
   self.play(Transform(circle, square))
   self.play(FadeOut(circle))
   ```

---

## Reference Template
Check out the complete working script in:
[explainer_scene.py](./examples/explainer_scene.py)
