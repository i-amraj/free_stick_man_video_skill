from manim import *

class ExplainerScene(Scene):
    def construct(self):
        # Background color
        self.camera.background_color = "#0B0F19"

        # Title
        title = Text("Exponential Growth in Action", font="sans-serif", font_size=36, color=WHITE)
        title.to_edge(UP, buff=0.8)
        self.play(Write(title), run_time=1.2)

        # Coordinate axes
        axes = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 32, 8],
            x_length=6,
            y_length=4.5,
            axis_config={"color": GREY_B},
        ).shift(DOWN * 0.5)

        labels = axes.get_axis_labels(x_label="t", y_label="f(t)")
        self.play(Create(axes), Write(labels))

        # Exponential curve f(t) = 2^t
        graph = axes.plot(lambda x: 2**x, color=YELLOW, x_range=[0, 4.8])
        graph_label = axes.get_graph_label(graph, label=r"f(t) = 2^t", x_val=3.5, direction=UR)

        self.play(Create(graph), Write(graph_label), run_time=2)
        self.wait(1)

        # Highlight point
        dot = Dot(color=RED).move_to(axes.c2p(3, 8))
        dot_label = Text("(3, 8)", font_size=24, color=RED).next_to(dot, RIGHT)
        self.play(FadeIn(dot, scale=0.5), Write(dot_label))
        self.wait(2)

        # Fade out
        self.play(FadeOut(Group(title, axes, labels, graph, graph_label, dot, dot_label)))
