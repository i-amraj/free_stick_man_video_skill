# Viral Short Retention & Engagement Rules

### 1. Pacing & Cut Frequency
* **Cut frequency**: Change visual stimulus or camera angle every **2.0 to 2.8 seconds**.
* **Micro-Zooms**: Add a subtle 105% to 110% punch-in zoom during key punchlines or strong words.
* **Audio ducking**: Lower background music by **18dB to 22dB** whenever speech is active.

### 2. Caption Styling & Psychology
* **Words Per Screen**: Display at most **2 to 4 words** at a time (MrBeast / Hormozi style) rather than full sentences.
* **Colors**:
  * **White text** with heavy black stroke/shadow for readability.
  * **Bright Yellow (`#FFE600`) or Neon Green (`#22C55E`)** highlighting the active spoken word.
  * **Red (`#EF4444`)** for danger, shock, or negative trigger words.
* **Placement**: Center-screen (`y = 50%` to `y = 65%`). Keep clear of the top UI and bottom caption/title area of TikTok/Reels.

### 3. Audio & SFX Triggers
* **Whoosh / Swoosh**: Every time text or a new image slides in.
* **Subtle Pop / Click**: On every word or icon reveal.
* **Low Boom / Riser**: Leading into the twist or reveal.
