---
name: short-video-pipeline
description: >-
  Automates end-to-end creation of high-retention viral YouTube Shorts, Instagram Reels,
  and TikTok videos (especially Fact and Explainer channels). Handles script writing,
  text-to-speech (TTS), background music ducking, dynamic B-roll, and animated subtitles.
---

# Viral Short Video Generator Pipeline

Use this skill to autonomously produce complete 30-60 second vertical (9:16) videos for Shorts, Reels, and TikToks.

## High-Retention Formula (The 3-Second Rule)
1. **The Hook (0s - 3s)**: Shocking statement, counter-intuitive question, or visual disruption.
2. **The Escalation (3s - 25s)**: Fast-paced delivery, changing scene/visual every 2.5 to 3 seconds.
3. **The Climax / Twist (25s - 45s)**: The unexpected truth or punchline.
4. **The Seamless Loop (Ending)**: Final sentence seamlessly connects back into the opening hook for infinite playback loops.

---

## Complete Pipeline Architecture

```text
[Topic / Fact] 
      │
      ├──> 1. Script Generation (Hook + Narrative + Loop)
      │
      ├──> 2. Voiceover Audio (Edge-TTS / ElevenLabs)
      │
      ├──> 3. Timestamped Transcripts (Faster-Whisper / Word Timestamps)
      │
      ├──> 4. Dynamic Visuals (Image Generation / Stock B-roll / Motion Graphics)
      │
      └──> 5. Final Render with Auto-Captions & Background Music Ducking (-18dB)
```

---

## 1-Command Automated Generation
Run the bundled generation script:
```bash
python .agents/skills/short-video-pipeline/scripts/generate_short.py --topic "Mindblowing Space Facts" --output final_short.mp4
```

## Quick Manual Commands

### 1. Free High-Quality Voiceover using `edge-tts`:
```bash
# Install edge-tts if not already present
pip install edge-tts

# Generate natural Hindi or English voiceover
edge-tts --voice en-US-ChristopherNeural --text "Did you know that one day on Venus is longer than its entire year?" --write-media voiceover.mp3
```

### 2. Auto-generate Word-by-Word Subtitles:
Use whisper with word-level timestamps to generate `.srt` or `.ass` format:
```bash
whisper voiceover.mp3 --model base --output_format srt
```

### 3. Assemble Audio + Background Music (Ducked) + Video:
```bash
ffmpeg -i bg_video.mp4 -i voiceover.mp3 -i music.mp3 -filter_complex "[2:a]volume=0.15[bgm];[1:a][bgm]amix=inputs=2:duration=first[aout]" -map 0:v -map "[aout]" -shortest -c:v copy output.mp4
```

---

## Best Practices & Retention Strategies
Read [retention_rules.md](./references/retention_rules.md) for pacing, caption color psychology, and sound effects (SFX) triggers.
