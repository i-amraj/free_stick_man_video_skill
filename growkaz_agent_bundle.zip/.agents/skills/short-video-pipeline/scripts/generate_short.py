"""
Automated Short / Reel Video Generator.
Synthesizes speech using edge-tts, generates animated background / captions,
and stitches the final video using FFmpeg.
"""

import argparse
import asyncio
import os
import subprocess
import sys

async def generate_speech(text: str, voice: str, output_path: str):
    try:
        import edge_tts
    except ImportError:
        print("Installing edge-tts...")
        subprocess.run([sys.executable, "-m", "pip", "install", "edge-tts"], check=True)
        import edge_tts

    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(output_path)
    print(f"Generated voiceover: {output_path}")

def get_audio_duration(file_path: str) -> float:
    cmd = [
        "ffprobe", "-v", "error", "-show_entries",
        "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", file_path
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, text=True, check=True)
    return float(proc.stdout.strip())

def assemble_video(audio_path: str, output_path: str, title_text: str):
    duration = get_audio_duration(audio_path)
    
    # Generate vertical 1080x1920 video with dynamic gradient background and centered typography
    filter_complex = (
        f"color=c=0x0F172A:s=1080x1920:d={duration}[bg];"
        f"[bg]drawtext=text='{title_text}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=(h-text_h)/2:"
        f"box=1:boxcolor=0x00000088:boxborderw=20[v]"
    )

    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", f"color=c=0x0a0f1d:s=1080x1920:d={duration}",
        "-i", audio_path,
        "-vf", f"drawtext=text='{title_text}':fontcolor=0xFFFFFF:fontsize=48:line_spacing=20:box=1:boxcolor=0x111827AA:boxborderw=30:x=(w-text_w)/2:y=(h-text_h)/2",
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest", output_path
    ]
    subprocess.run(cmd, check=True)
    print(f"Video created successfully at: {output_path}")

def main():
    parser = argparse.ArgumentParser(description="Generate automated short video.")
    parser.add_argument("--topic", default="Did you know? Honey never spoils.", help="Topic or text content")
    parser.add_argument("--voice", default="en-US-ChristopherNeural", help="Edge TTS voice")
    parser.add_argument("--output", default="final_short.mp4", help="Output file path")
    args = parser.parse_args()

    audio_file = "temp_voiceover.mp3"
    print(f"Creating voiceover for: {args.topic}")
    asyncio.run(generate_speech(args.topic, args.voice, audio_file))

    print("Assembling video layout...")
    assemble_video(audio_file, args.output, args.topic)

    if os.path.exists(audio_file):
        os.remove(audio_file)

if __name__ == "__main__":
    main()
