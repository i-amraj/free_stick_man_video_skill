"""
Converts a still image into a cinematic 9:16 vertical video using Ken Burns camera moves.
"""

import argparse
import subprocess
import os
import sys

def animate_image(image_path: str, output_path: str, motion: str = "zoom-in", duration: float = 4.0, fps: int = 30):
    total_frames = int(duration * fps)
    
    if motion == "zoom-in":
        zoom_filter = (
            f"scale=8000:-1,"
            f"zoompan=z='min(zoom+0.0018,1.3)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"d={total_frames}:s=1080x1920:fps={fps},"
            f"vignette=PI/5"
        )
    elif motion == "zoom-out":
        zoom_filter = (
            f"scale=8000:-1,"
            f"zoompan=z='if(lte(zoom,1.0),1.3,max(1.001,zoom-0.0018))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"d={total_frames}:s=1080x1920:fps={fps},"
            f"vignette=PI/5"
        )
    elif motion == "pan-left":
        zoom_filter = (
            f"scale=8000:-1,"
            f"zoompan=z=1.2:x='if(lte(on,1),(iw-iw/zoom),max(0,x-2))':y='ih/2-(ih/zoom/2)':"
            f"d={total_frames}:s=1080x1920:fps={fps},"
            f"vignette=PI/5"
        )
    else:  # pan-right
        zoom_filter = (
            f"scale=8000:-1,"
            f"zoompan=z=1.2:x='if(lte(on,1),0,min(iw-iw/zoom,x+2))':y='ih/2-(ih/zoom/2)':"
            f"d={total_frames}:s=1080x1920:fps={fps},"
            f"vignette=PI/5"
        )

    cmd = [
        "ffmpeg", "-y",
        "-loop", "1",
        "-i", image_path,
        "-vf", zoom_filter,
        "-t", str(duration),
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        output_path
    ]

    try:
        subprocess.run(cmd, check=True)
        print(f"Animated B-roll saved to {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error animating image: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Animate still image into 9:16 vertical video.")
    parser.add_argument("image", help="Input image file")
    parser.add_argument("output", help="Output video file")
    parser.add_argument("--motion", choices=["zoom-in", "zoom-out", "pan-left", "pan-right"], default="zoom-in", help="Camera motion")
    parser.add_argument("--duration", type=float, default=4.0, help="Duration in seconds")
    parser.add_argument("--fps", type=int, default=30, help="Frames per second")
    args = parser.parse_args()

    animate_image(args.image, args.output, args.motion, args.duration, args.fps)

if __name__ == "__main__":
    main()
