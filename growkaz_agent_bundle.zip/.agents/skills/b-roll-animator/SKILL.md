---
name: b-roll-animator
description: >-
  Converts static images and artwork into dynamic cinematic 9:16 video clips using Ken Burns
  camera moves (slow zoom-in, zoom-out, pan-tilt), subtle vignettes, and atmospheric motion.
---

# B-Roll Animator & Ken Burns Skill

Use this skill to convert still images (AI generated via Midjourney/Flux/Imagen or downloaded stock photos) into continuous 1080x1920 video clips with camera movement so fact videos never look flat or static.

## Motion Presets
1. **Slow Zoom In**: Draws audience focus inward toward the subject (increases intensity).
2. **Slow Zoom Out**: Reveals environment context and scale.
3. **Pan Left to Right / Right to Left**: Simulates a dolly track movement across landscape imagery.
4. **Cinematic Vignette & Atmospheric Contrast**: Darkens edges to make bright subtitles pop in the center.

---

## 1-Command Image to Video Conversion
Run the bundled script:
```bash
python .agents/skills/b-roll-animator/scripts/animate_image.py input.png output.mp4 --motion zoom-in --duration 4
```

Supported motions: `zoom-in`, `zoom-out`, `pan-left`, `pan-right`.

---

## FFmpeg Filter Snippets

### 1. Slow Zoom-In (Ken Burns):
```bash
ffmpeg -loop 1 -i image.jpg -vf "scale=8000:-1,zoompan=z='min(zoom+0.0015,1.25)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=120:s=1080x1920:fps=30" -t 4 -c:v libx264 -pix_fmt yuv420p output.mp4
```

### 2. Slow Zoom-Out (Revealing Scope):
```bash
ffmpeg -loop 1 -i image.jpg -vf "scale=8000:-1,zoompan=z='if(lte(zoom,1.0),1.25,max(1.001,zoom-0.0015))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=120:s=1080x1920:fps=30" -t 4 -c:v libx264 -pix_fmt yuv420p output.mp4
```

### 3. Add Dark Vignette (For Subtitle Readability):
```bash
ffmpeg -i input.mp4 -vf "vignette=PI/4" -c:a copy output_vignette.mp4
```
