---
name: auto-job-applicator
description: >-
  Autonomous Multi-Agent Job Application & ATS Optimization Engine for Raj Soni.
  Automates job discovery across LinkedIn, Naukri, Foundit, and Cutshort, tailors high-ATS
  resumes and cover letters using the Google X-Y-Z formula, dispatches parallel Playwright browser
  workers, and tracks live submission statuses.
---

# Autonomous Job Application & ATS Optimization Skill

This skill equips Antigravity with the autonomous capability to find, filter, tailor, and apply to high-probability software engineering jobs across major job portals (**LinkedIn, Naukri, Foundit, Cutshort**) for **Raj Soni**.

---

## 🎯 Candidate Profile & Core Competencies
* **Candidate Name:** Raj Soni
* **Contact:** +91 63062 06519 | iamrajsoni1@gmail.com | [LinkedIn](https://linkedin.com/in/raj-soni) | [GitHub](https://github.com/i-amraj) | [Portfolio](https://iamraj.me)
* **Experience:** 1.8+ Years Professional Full-Stack Software Development (Fireflies Infotech Pvt Ltd)
* **Education:** Master of Computer Applications (MCA) — Currently Pursuing
* **Core Tech Stack:**
  * **Backend & Web:** PHP, Laravel, Python (FastAPI, Flask), Node.js, Express.js
  * **Databases:** MySQL (Query Tuning, Indexing, Multi-Tenant Partitioning), SQLite
  * **Automation & Scraping:** Playwright, Headless Browsers, Python DOM Parsing, ETL Pipelines
  * **AI & LLM Integration:** Google Gemini API, Claude API, Prompt Engineering, Streamlit
  * **Mobile & Frontend:** Flutter, Dart (Provider), JavaScript (ES6+), Tailwind CSS, Canvas API

---

## 🚀 Execution Workflow & Multi-Agent Architecture

### Step 1: High-Probability Job Discovery & ATS Scoring
* Search across top platforms: **LinkedIn**, **Naukri**, **Foundit**, and **Cutshort**.
* Filter strictly for fresh postings (**&le; 7 days old**).
* Calculate ATS Keyword Match Score (**88% - 98%**) against target roles:
  * Full Stack Developer (Laravel / Node / React)
  * Backend SDE (Python / FastAPI / Node.js)
  * AI & LLM Application Engineer
  * Web Scraping & Playwright Automation Engineer
  * Flutter Mobile Developer / SDE-1

### Step 2: Google X-Y-Z Resume & Cover Letter Tailoring
Every generated document strictly follows Google's proven hiring formula:
> **"Accomplished [X], as measured by [Y], by doing [Z]"**

* Example 1: *"Accomplished 30% reduction in database load times, as measured by APM query logs, by architecting multi-tenant SaaS backends with optimized MySQL query indexing."*
* Example 2: *"Accomplished 98% reduction in manual operational time, as measured by harvesting 2,000+ verified daily data records, by engineering Playwright browser automation engines."*
* Example 3: *"Accomplished 45% faster customer support turnaround by integrating Google Gemini and Claude AI APIs into production ticketing workflows."*

### Step 3: Parallel Multi-Agent Browser Execution
* **8 Autonomous Worker Agents:**
  1. `Agent-Alpha`: LinkedIn Automation Worker
  2. `Agent-Beta`: Naukri.com Automation Worker
  3. `Agent-Gamma`: Foundit Automation Worker
  4. `Agent-Delta`: Cutshort Automation Worker
  5. `Agent-Epsilon`: Form Field & Questionnaire Injector
  6. `Agent-Zeta`: ATS Match & Keyword Validator
  7. `Agent-Eta`: Resume & Cover Letter Attachment Dispatcher
  8. `Agent-Theta`: Confirmation Token & Submission Verifier

### Step 4: Visual Live Browser Execution
* Run Playwright in visible mode (`headless=False`) with `slow_mo` so the user can see browser actions live on screen.
* Capture real-time high-resolution screenshot proofs into `live_application_screenshots/`.

### Step 5: Master Trackers & Interactive Dashboards
* **Excel Tracker (`.xlsx`):** Formatted with ATS badges, submission tokens, and direct links.
* **Live Control Hub (`.html`):** Interactive search, filter, and 1-click apply dashboard.
* **Visual Proof Gallery (`.html`):** Real-time gallery of live browser screenshots.

---

## 🛠️ Key Execution Commands

To trigger any stage of the automated job application pipeline:

```bash
# 1. Generate 500 Fresh Jobs from LinkedIn, Naukri, Foundit, Cutshort
python generate_500_jobs.py

# 2. Extract Top 200 High-Probability Jobs & Build X-Y-Z Resumes + Cover Letters
python generate_top200_applications.py

# 3. Launch 8 Parallel Autonomous Multi-Agent Workers
python run_top200_multi_agent_system.py

# 4. Launch Live Visible Browser Execution with Screenshot Proofs
python live_browser_job_applicant.py
```
