---
name: visual-analyzer
description: >-
  Inspects, audits, and visually analyzes videos and images. Generates keyframe contact sheets,
  evaluates scene transition frequency, checks vertical safe zones (TikTok/Reels UI overlays),
  and verifies subtitle contrast and visual pacing.
---

# Visual Analyzer & Video QA Skill

Use this skill when auditing raw clips, reviewing rendered videos for quality control, verifying UI safe-zone compliance, or inspecting visual pacing.

## Core Capabilities
1. **Keyframe Grid & Contact Sheets**: Extract 3x3 or 4x4 image grids from video to inspect every scene at a glance without replaying the entire file.
2. **Scene Transition Detection**: Calculate cuts per minute and detect scene change timestamps using FFmpeg.
3. **Safe Zone Verification**: Ensure captions, faces, and text do not get hidden behind TikTok / Instagram Reels UI elements (like bottom captions, right-side like/comment buttons, or top header).
4. **Legibility & Contrast Check**: Confirm subtitles stand out clearly against bright or noisy backgrounds.

---

## Quick Inspection Tools

### 1. Generate a Visual Keyframe Contact Sheet
Run the bundled script to create a single high-resolution image preview of all key moments:
```bash
python .agents/skills/visual-analyzer/scripts/generate_contact_sheet.py input_video.mp4 --grid 3x3 --output contact_sheet.jpg
```

### 2. Detect Scene Cuts via FFmpeg
Find all scene transitions where the visual change exceeds 30%:
```bash
ffmpeg -i input_video.mp4 -filter_complex "select='gt(scene,0.3)',metadata=print:file=scene_cuts.txt" -f null -
```

### 3. Check Vertical Safe Zones (9:16 Shorts/Reels)
* **Top 15% (0px to 280px)**: Header area (channel name, search, sounds). **Do NOT place text here.**
* **Bottom 25% (1440px to 1920px)**: Caption, music title, hashtags. **Keep subtitles above 1440px.**
* **Right 15% (920px to 1080px)**: Like, comment, share, bookmark buttons. **Avoid placing key focal points on the right edge.**
* **Optimal Caption Zone**: Center of screen, `y = 960px` to `y = 1350px`.

See detailed diagram in:
[safe_zones.md](./references/safe_zones.md)
