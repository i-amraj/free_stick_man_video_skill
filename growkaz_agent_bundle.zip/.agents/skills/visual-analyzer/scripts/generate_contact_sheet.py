"""
Generates a contact sheet / thumbnail storyboard grid from a video using FFmpeg.
"""

import argparse
import subprocess
import sys

def generate_contact_sheet(video_path: str, output_path: str, grid: str = "3x3"):
    cols, rows = map(int, grid.lower().split("x"))
    total_tiles = cols * rows

    # Use select filter to pick evenly distributed frames across the video
    filter_complex = (
        f"select='not(mod(n\\,max(1\\,floor(N/{total_tiles}))))',"
        f"scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,"
        f"tile={cols}x{rows}:nb_frames={total_tiles}:padding=10:color=black"
    )

    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-vf", filter_complex,
        "-frames:v", "1",
        "-q:v", "2",
        output_path
    ]
    try:
        subprocess.run(cmd, check=True)
        print(f"Generated contact sheet: {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error creating contact sheet: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Generate video contact sheet grid.")
    parser.add_argument("video", help="Path to input video")
    parser.add_argument("--grid", default="3x3", help="Grid dimension (e.g. 3x3 or 4x4)")
    parser.add_argument("--output", default="contact_sheet.jpg", help="Output image file")
    args = parser.parse_args()

    generate_contact_sheet(args.video, args.output, args.grid)

if __name__ == "__main__":
    main()
