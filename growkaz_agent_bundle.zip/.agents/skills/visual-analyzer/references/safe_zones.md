# 9:16 Shorts & Reels Safe Zone Guide

When rendering 1080x1920 vertical videos, social platforms place interactive overlays on top of the video content. Anything outside the safe zone risks getting clipped or blocked.

```text
+-----------------------+ 0px (Top)
|  DANGER: App Header   | Height: ~280px (Search icon, back button, camera)
+-----------------------+ 280px
|                       |
|                       |
|      SAFE ZONE        | Width: 920px
|                       | (Keep all primary text, faces & logos here)
|   [ Optimal Captions] | y = 960px to 1350px
|                       |
+-----------------------+ 1440px
|  DANGER: UI Buttons   | Height: ~480px (Like, Comment, Share on right side)
|  & Caption / Soundbar | Height: ~300px (Username & Description at bottom)
+-----------------------+ 1920px (Bottom)
```

### Key Margins:
- **Top Margin**: Keep key elements at least **300px** down from the top.
- **Bottom Margin**: Keep subtitles and text at least **450px** above the bottom.
- **Right Margin**: Leave at least **160px** clearance from the right edge for interactive action buttons.
- **Safe Center Rectangle**: `x: 80px to 1000px`, `y: 320px to 1440px`.
