"""
YouTube Title & Thumbnail Packaging Linter.
Audits title length, redundancy between title and thumbnail, curiosity gap, and mobile readability.
"""

import argparse
import sys

def lint_packaging(title: str, thumbnail_text: str = ""):
    issues = []
    strengths = []
    score = 100

    title_len = len(title)
    words_title = set(title.lower().replace("?", "").replace("!", "").split())
    words_thumb = set(thumbnail_text.lower().replace("?", "").replace("!", "").split()) if thumbnail_text else set()

    # 1. Title Length Check
    if title_len > 60:
        issues.append(f"Title is too long ({title_len} chars). On mobile devices, it will be cut off after ~50 characters.")
        score -= 20
    elif title_len <= 50:
        strengths.append(f"Optimal title length ({title_len} chars) - 100% visible on mobile without truncation.")

    # 2. Thumbnail Word Count Check
    if thumbnail_text:
        thumb_word_count = len(thumbnail_text.split())
        if thumb_word_count > 4:
            issues.append(f"Thumbnail text has {thumb_word_count} words. Ideal thumbnail text is 1-3 high-impact words.")
            score -= 15
        else:
            strengths.append(f"Thumbnail text is punchy ({thumb_word_count} words).")

        # 3. Redundancy Check
        overlap = words_title.intersection(words_thumb)
        # Exclude common stop words
        stop_words = {"the", "a", "an", "in", "on", "at", "to", "for", "is", "of", "and"}
        meaningful_overlap = overlap - stop_words
        if meaningful_overlap:
            issues.append(f"Redundant words found between title and thumbnail: {list(meaningful_overlap)}. Make them complement rather than duplicate each other.")
            score -= 20
        else:
            strengths.append("Zero redundant words between title and thumbnail (Great 1-2 punch!).")

    # 4. Curiosity Gap / Power Words
    power_words = {"why", "how", "secret", "never", "banned", "illegal", "survive", "discovered", "real", "truth", "hidden"}
    found_power = [w for w in power_words if w in words_title or w in words_thumb]
    if found_power:
        strengths.append(f"Contains high-CTR power triggers: {found_power}")
    else:
        issues.append("Consider adding a curiosity trigger (e.g. 'Why', 'Never', 'Real Truth', 'Hidden').")
        score -= 10

    # Summary Output
    print("=" * 60)
    print(f"YOUTUBE PACKAGING AUDIT REPORT")
    print("=" * 60)
    print(f"Title:          \"{title}\"")
    if thumbnail_text:
        print(f"Thumbnail Text: \"{thumbnail_text}\"")
    print(f"Packaging Score: {max(0, score)} / 100\n")

    if strengths:
        print("STRENGTHS:")
        for s in strengths:
            print(f"  + {s}")
        print()

    if issues:
        print("RECOMMENDATIONS:")
        for i in issues:
            print(f"  - {i}")
    else:
        print("Grade: EXCELLENT! High probability of strong click-through rate (CTR).")
    print("=" * 60)

def main():
    parser = argparse.ArgumentParser(description="Lint YouTube title & thumbnail pairing.")
    parser.add_argument("--title", required=True, help="Video title")
    parser.add_argument("--thumbnail-text", default="", help="Text written on thumbnail image")
    args = parser.parse_args()

    lint_packaging(args.title, args.thumbnail_text)

if __name__ == "__main__":
    main()
