"""
YouTube Video Transcript and Metadata Extractor.
Uses youtube-transcript-api or yt-dlp to download subtitles/transcripts for competitor research.
"""

import argparse
import json
import re
import subprocess
import sys

def extract_video_id(url_or_id: str) -> str:
    match = re.search(r"(?:v=|\/shorts\/|youtu\.be\/)([0-9A-Za-z_-]{11})", url_or_id)
    if match:
        return match.group(1)
    if len(url_or_id) == 11:
        return url_or_id
    raise ValueError(f"Could not extract YouTube video ID from: {url_or_id}")

def get_transcript(video_id: str):
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except ImportError:
        print("Installing youtube-transcript-api...")
        subprocess.run([sys.executable, "-m", "pip", "install", "youtube-transcript-api"], check=True)
        from youtube_transcript_api import YouTubeTranscriptApi

    print(f"Fetching transcript for video ID: {video_id}...")
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=['en', 'hi'])
        return transcript
    except Exception as e:
        print(f"Standard fetch failed ({e}). Trying auto-generated subtitles...")
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        transcript = transcript_list.find_transcript(['en', 'hi']).fetch()
        return transcript

def main():
    parser = argparse.ArgumentParser(description="Fetch YouTube video transcript.")
    parser.add_argument("url", help="YouTube video URL or Video ID")
    parser.add_argument("--output", default="transcript.json", help="Output JSON file")
    args = parser.parse_args()

    try:
        video_id = extract_video_id(args.url)
        data = get_transcript(video_id)
        
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            
        print(f"Successfully saved transcript with {len(data)} lines to: {args.output}")
        
        # Display first 5 lines as preview
        print("\nPreview of first few moments:")
        for line in data[:5]:
            start = round(line.get('start', 0), 1)
            text = line.get('text', '')
            print(f"  [{start}s] {text}")
            
    except Exception as err:
        print(f"Error fetching transcript: {err}")
        sys.exit(1)

if __name__ == "__main__":
    main()
