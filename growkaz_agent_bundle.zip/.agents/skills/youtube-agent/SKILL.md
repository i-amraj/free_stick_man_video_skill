---
name: youtube-agent
description: >-
  Complete YouTube channel growth, scripting, packaging, and optimization suite.
  Features 21 viral hook formulas, title & thumbnail CTR linter, transcript analysis,
  competitor research, SEO metadata, and audience retention optimization.
---

# YouTube Channel & Growth Agent Skill

Inspired by the open-source `youtube-agent-skill` standard, this skill equips the agent to act as a YouTube strategist, script doctor, packaging expert, and retention optimizer.

## Core Capabilities
1. **Packaging & CTR Linter**: Validates title and thumbnail concepts together. Enforces brevity (<50 chars), curiosity gaps, and emotional stakes without cheap clickbait.
2. **21 Viral Hook Formulas**: Scores and writes opening hooks (0s - 3s) across 21 proven formats to stop viewer swipe-away / drop-off.
3. **Transcript & Competitor Intelligence**: Extracts transcripts from any YouTube URL to analyze pacing, structure, and why top videos went viral.
4. **Retention Doctor (EDL Analysis)**: Identifies dead zones, repetitive explanations, and recommends pattern interrupts.
5. **SEO & Shorts Packaging**: Generates high-converting descriptions, optimized hashtags, pinned comment hooks, and searchable tags.

---

## Bundled Tools & Workflows

### 1. Title & Thumbnail Linter
Run the title & thumbnail grader to test your packaging before recording:
```bash
python .agents/skills/youtube-agent/scripts/title_thumbnail_linter.py --title "Why Honey Never Spoils Even After 3,000 Years" --thumbnail-text "STILL EDIBLE?"
```

### 2. Extract Transcript from YouTube Video
Download timestamped transcripts from any viral competitor video to study their pacing:
```bash
python .agents/skills/youtube-agent/scripts/fetch_transcript.py "https://www.youtube.com/watch?v=VIDEO_ID"
```

### 3. Apply 21 Hook Formulas
Score and craft hooks using the complete taxonomy:
[21_hook_formulas.md](./references/21_hook_formulas.md)

---

## Packaging Golden Rules (The 1-2 Punch)
1. **Never Duplicate Words**: If the thumbnail says *"BANNED IN 50 COUNTRIES"*, the title must NOT say *"Banned in 50 countries"*. The title should provide context: *"The Map Airlines Are Hiding From You"*.
2. **The 3-Element Rule**: A thumbnail must have at most 3 visual focal points (e.g., Face + Object + 3 words of text).
3. **Character Limit**: Keep titles under **50 characters** so they don't get truncated on mobile devices.
4. **Curiosity Gap vs. Disappointment**: Promise a high-stakes question in the title, and deliver the answer with a twist within the first 60% of the video.
