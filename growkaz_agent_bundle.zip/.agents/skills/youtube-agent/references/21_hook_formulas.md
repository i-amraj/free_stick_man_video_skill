# The 21 Viral Hook Formulas for YouTube & Shorts

### Category 1: The Curiosity Disruptors
1. **The Counter-Intuitive Truth**: State something that contradicts common intuition.
   * *Example: "Drinking cold water actually burns more calories than drinking hot water."*
2. **The Negative Hook**: Challenge assumptions or expose a lie.
   * *Example: "Stop storing your tomatoes in the fridge—here is what it's doing to them."*
3. **The Hidden Warning**: Trigger self-preservation instinct.
   * *Example: "If you ever smell cucumber in your bedroom at night, leave immediately."*
4. **The Scale Shock**: Frame numbers in an unimaginable comparison.
   * *Example: "If the Earth were the size of a grain of sand, the Sun would be a basketball 100 feet away."*
5. **The Unresolved Mystery**: Introduce an open loop that demands resolution.
   * *Example: "In 1518, hundreds of people started dancing in the streets until they dropped dead—and science still can't explain it."*

### Category 2: Stakes & Urgency
6. **The What-If Scenario**: High-stakes hypothetical.
   * *Example: "What would happen to your body if you fell into a black hole feet first?"*
7. **The Time Limit Countdown**:
   * *Example: "You have exactly 8 minutes before this asteroid hits Earth—here is what happens."*
8. **The Extreme Experiment**:
   * *Example: "I spent 7 days locked inside an anechoic chamber where sound literally doesn't exist."*
9. **The Banned Knowledge**:
   * *Example: "This is the real reason why GPS is secretly inaccurate on purpose."*
10. **The Direct Accusation**:
    * *Example: "You are breathing wrong right now, and it's making you exhausted."*

### Category 3: Visual & Pattern Interrupts
11. **The Mid-Action Freeze**: Start with the climax, pause, and rewind.
    * *Example: "[Explosion freezes] You're probably wondering how I ended up in this situation..."*
12. **The Micro-Mystery**: Show an unusual object with no context for 2 seconds.
    * *Example: "This tiny metal sphere is worth more than 50 tons of gold."*
13. **The Reverse Question**:
    * *Example: "Why doesn't ocean water simply drain into the Earth's molten core?"*
14. **The Superlative Extreme**:
    * *Example: "This is officially the most dangerous staircase on the planet."*
15. **The Sensory Hook**:
    * *Example: "Listen very closely to this sound—it was recorded 7 miles beneath the ocean surface."*

### Category 4: Story & Character Loops
16. **The David vs Goliath Fact**:
    * *Example: "How one single mathematical error cost NASA 327 million dollars."*
17. **The Inverted Timeline**: Start with the consequence.
    * *Example: "Because of one missing comma, this company lost 5 million dollars in court."*
18. **The Secret Double-Life**:
    * *Example: "The quiet librarian who was secretly the CIA's top codebreaker."*
19. **The Accidental Invention**:
    * *Example: "The world's most famous medicine was discovered completely by accident on moldy bread."*
20. **The Forbidden Place**:
    * *Example: "There is an island where visitors are legally shot on sight."*
21. **The Infinite Seamless Loop**: End the video with the setup sentence that seamlessly restarts the hook.
    * *Example Ending: "...which explains why thousands of people ask..." -> (Loops back to start: "Why does airplane food taste different?")*
