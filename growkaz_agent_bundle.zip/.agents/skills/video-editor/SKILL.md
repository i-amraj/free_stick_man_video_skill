---
name: video-editor
description: >-
  Automates video editing workflows including silence removal, jumpcuts,
  audio normalization (-14 LUFS), format reframing (16:9 to 9:16 Shorts/Reels),
  dynamic subtitle burning, and FFmpeg filter pipelines.
---

# Video Editor & Post-Production Skill

Use this skill when editing raw footage, trimming silence, reframing aspect ratios, mixing audio, or generating subtitles with FFmpeg and Python.

## Core Capabilities
1. **Silence Removal & Jumpcuts**: Detect and strip silent pauses (>0.5s) to maintain high retention.
2. **Audio Balancing & Normalization**: Standardize loudness to `-14 LUFS` (YouTube/Reels standard) with smooth audio fades.
3. **Aspect Ratio Reframing**: Convert 16:9 landscape to 9:16 vertical shorts with smart auto-centering or blurred background padding.
4. **Subtitles & Captions**: Burn stylized `.ass` or `.srt` captions with custom fonts, colors, and word-by-word highlights.
5. **Hardware Accelerated Encoding**: Use NVIDIA (`h264_nvenc`) or Intel QuickSync (`h264_qsv`) for high-speed rendering.

---

## Standard Workflows

### 1. Remove Silence & Auto-Jumpcut
Use the bundled Python script:
```bash
python .agents/skills/video-editor/scripts/auto_silence_cut.py input.mp4 output_cut.mp4 --threshold -30 --min-silence 500
```
Or with pure FFmpeg `silencedetect`:
```bash
ffmpeg -i input.mp4 -af "silencedetect=noise=-30dB:d=0.5" -f null -
```

### 2. Audio Normalization (EBU R128 / -14 LUFS)
```bash
ffmpeg -i input.mp4 -af loudnorm=I=-14:LRA=7:tp=-1.5 -c:v copy output_normalized.mp4
```

### 3. Convert 16:9 to 9:16 (Blurred Background Style)
Puts the 16:9 video centered with a blurred, zoomed background:
```bash
ffmpeg -i input.mp4 -filter_complex "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:20[bg];[0:v]scale=1080:1920:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2" -c:a copy output_916.mp4
```

### 4. Burn Subtitles into Video
```bash
ffmpeg -i input.mp4 -vf "subtitles=subtitles.srt:force_style='FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=3,Outline=2,Alignment=2'" -c:a copy output_subbed.mp4
```

### 5. High-Speed Export (NVENC GPU)
```bash
ffmpeg -i input.mp4 -c:v h264_nvenc -preset p6 -b:v 8M -c:a aac -b:a 192k output.mp4
```

---

## Detailed References
For more filter recipes (speed ramping, video overlays, green screen chroma keying), refer to:
[ffmpeg_cheatsheet.md](./references/ffmpeg_cheatsheet.md)
