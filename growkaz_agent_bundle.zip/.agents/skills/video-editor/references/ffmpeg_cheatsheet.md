# FFmpeg Production Cheatsheet

### 1. Speed Ramping (Change Video Speed)
* **2x Speed (Video & Audio):**
  ```bash
  ffmpeg -i input.mp4 -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]" -map "[v]" -map "[a]" output.mp4
  ```
* **0.5x Slow Motion:**
  ```bash
  ffmpeg -i input.mp4 -filter_complex "[0:v]setpts=2.0*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]" output.mp4
  ```

### 2. Picture-in-Picture (PiP / Webcam Overlay)
Places an overlay video in the bottom right corner:
```bash
ffmpeg -i main.mp4 -i webcam.mp4 -filter_complex "[1:v]scale=320:180[cam];[0:v][cam]overlay=main_w-overlay_w-20:main_h-overlay_h-20" -c:a copy output.mp4
```

### 3. Green Screen (Chroma Key) Removal
Removes green screen (`0x00FF00`) and overlays on background image/video:
```bash
ffmpeg -i background.mp4 -i greenscreen.mp4 -filter_complex "[1:v]colorkey=0x00FF00:0.3:0.1[ckout];[0:v][ckout]overlay=x=0:y=0" output.mp4
```

### 4. Audio Fade In & Fade Out
```bash
ffmpeg -i input.mp4 -af "afade=t=in:ss=0:d=1,afade=t=out:st=10:d=1" output.mp4
```

### 5. Extract MP3 Audio from Video
```bash
ffmpeg -i input.mp4 -vn -acodec libmp3lame -q:a 2 audio.mp3
```

### 6. High-Quality GIF Generation
```bash
ffmpeg -i input.mp4 -vf "fps=15,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" -loop 0 output.gif
```
